<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Challenge 9 - 22.11.4813</title>
</head>
<body>
    <h2>Challenge Praktikum Minggu ke-9</h2>
    <form method="POST">
        <table border="0">
            <tr>
                <td>Nama :</td>
                <td><input type="text" name="nama"></td>
            </tr>
            <tr>
                <td>Email :</td>
                <td><input type="email" name="email"></td>
            </tr>
            <tr>
                <td>Password :</td>
                <td><input type="password" name="password"></td>
            </tr>
            <tr>
                <td>Jenis Kelamin :</td>
                <td>
                    <select name="jkelamin">
                        <option value="Pria">Pria</option>
                        <option value="Wanita">Wanita</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Alamat :</td>
                <td><textarea name="alamat" rows="4" cols="20"></textarea></td>
            </tr>
            <tr>
                <td>
                    <input type="submit" name="kirim" value="Kirim">
                    <input type="submit" name="reset" value="Reset">
                </td>
            </tr>
        </table>
    </form>

    <?php
        if (isset($_POST['kirim'])) {
            $nama = $_POST['nama'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $jkelamin = $_POST['jkelamin'];
            $alamat = $_POST['alamat'];

            $adaKesalahan = false;
            if (empty($nama)) {
                $adaKesalahan = true;
                $indikasiSalah[] = "Nama";
            }
            if (empty($email)) {
                $adaKesalahan = true;
                $indikasiSalah[] = "Email";
            }
            if (empty($password)) {
                $adaKesalahan = true;
                $indikasiSalah[] = "Password";
            }
            if (empty($jkelamin)) {
                $adaKesalahan = true;
                $indikasiSalah[] = "Jenis Kelamin";
            }
            if (empty($alamat)) {
                $adaKesalahan = true;
                $indikasiSalah[] = "Alamat";
            }

            if ($adaKesalahan) {
                echo "<p style='color: red;'>Kesalahan</p>";
                foreach ($indikasiSalah as $pesanError) {
                    echo $pesanError .", ";
                }
                echo "wajib diisi!! ";
                echo "<a href='Challenge9_4813.php'>Kembali</a>";
            } else {
                ?>
                <h3>Data Pengguna</h3>
                <table border="1px solid black;">
                    <tr>
                        <td>Nama</td>
                        <td><?= $nama ?></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td><?= $email ?></td>
                    </tr>
                    <tr>
                        <td>Password</td>
                        <td><?= $password ?></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td><?= $jkelamin ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td><?= $alamat ?></td>
                    </tr>
                </table>
                <?php
            }
        }
    ?>
</body>
</html>