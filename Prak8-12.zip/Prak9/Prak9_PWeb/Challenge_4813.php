<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Challenge Post & Get</title>
</head>
<body>
    <h2><u>Challenge 22.11.4813</u></h2>
    <p>
        <h3><font color="blue">Form Pendaftaran Mahasiswa Baru</font></h3>
        <form method="POST">
            <table border="0">
                <tr>
                    <td>NIM</td>
                    <td>:</td>
                    <td><input type="number" name="nim"></td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td>:</td>
                    <td><input type="text" name="nama"></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td>:</td>
                    <td>
                        <input type="radio" name="jkelamin" value="Laki-Laki">Laki-Laki
                        <input type="radio" name="jkelamin" value="Perempuan">Perempuan
                    </td>
                </tr>
                <tr>
                    <td>Tempat Lahir</td>
                    <td>:</td>
                    <td><input type="text" name="tmptlahir"></td>
                </tr>
                <tr>
                    <td>Tanggal Lahir</td>
                    <td>:</td>
                    <td><input type="date" name="tgllahir"></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>:</td>
                    <td><textarea name="alamat" rows="4" cols="50"></textarea></td>
                </tr>
                <tr>
                    <td>Program Studi</td>
                    <td>:</td>
                    <td>
                        <select name="prodi">
                            <option value="S1 Informatika">S1 Informatika</option>
                            <option value="S1 Sistem Informasi">S1 Sistem Informasi</option>
                            <option value="S1 Teknik Komputer">S1 Teknik Komputer</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Hobi</td>
                    <td>:</td>
                    <td>
                        <input type="checkbox" name="hobi" value="Membaca">Membaca
                        <input type="checkbox" name="hobi" value="Olahraga">Olahraga
                        <input type="checkbox" name="hobi" value="Musik">Musik
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" name="kirim" value="Kirim"></td>
                </tr>
            </table>
        </form>
    </p>

    <?php
        if (isset($_POST['kirim'])) {
            $nim = $_POST['nim'];
            $nama = $_POST['nama'];
            $jkelamin = $_POST['jkelamin'];
            $tmptlahir = $_POST['tmptlahir'];
            $tgllahir = $_POST['tgllahir'];
            $alamat = $_POST['alamat'];
            $prodi = $_POST['prodi'];
            $hobi[] = $_REQUEST['hobi'];

            echo "NIM Mahasiswa : $_POST[nim] <br>";
            echo "Nama Mahasiswa : $_POST[nama] <br>";
            echo "Jenis Kelamin : $_POST[jkelamin] <br>";
            echo "Tempat Lahir : $_POST[tmptlahir] <br>";
            echo "Tanggal Lahir : $_POST[tgllahir] <br>";
            echo "Alamat : $_POST[alamat] <br>";
            echo "Program Studi : $_POST[prodi] <br>";
            echo "Hobi : $_POST[hobi] <br>";
        }
    ?>
</body>
</html>