<?php
    if (isset($_GET['hitung'])) {
        $tinggi = $_GET['tinggi'];
        $panjang = $_GET['panjang'];

        $luas = ($tinggi * $panjang) / 2;
        echo "Nilai Tinggi = ".$tinggi."<br>";
        echo "Nilai Alas = ".$panjang."<br>";
        echo "Luas Persegi Panjang = ".$luas."<br>";
    } else {
        echo "<font color='red'>Masukkan nilai tinggi & panjang !";
    }
?>