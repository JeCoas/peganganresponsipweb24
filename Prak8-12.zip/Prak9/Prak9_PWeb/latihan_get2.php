<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latihan Post & Get</title>
</head>
<body>
    <h2><u>Latihan Method Get 2</u></h2>
    <p>
        <h3><font color="blue">Menghitung Luas Segitiga</font></h3>
        <form method="GET" action="simpan_get.php">
            <table border="0">
                <tr>
                    <td>Masukkan Nilai Tinggi</td>
                    <td>:</td>
                    <td><input type="text" name="tinggi"></td>
                </tr>
                <tr>
                    <td>Masukkan Nilai Panjang</td>
                    <td>:</td>
                    <td><input type="text" name="panjang"></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" name="hitung" value="hitung"></td>
                </tr>
            </table>
        </form>
    </p>
</body>
</html>