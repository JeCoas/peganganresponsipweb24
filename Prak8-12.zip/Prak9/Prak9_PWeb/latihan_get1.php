<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latihan Post & Get</title>
</head>
<body>
    <h2><u>Latihan Method Get 1</u></h2>
    <p>
        <h3><font color="blue">Menghitung Luas Persegi Panjang</font></h3>
        <form method="GET">
            <table border="0">
                <tr>
                    <td>Masukkan Nilai Tinggi</td>
                    <td>:</td>
                    <td><input type="text" name="tinggi"></td>
                </tr>
                <tr>
                    <td>Masukkan Nilai Panjang</td>
                    <td>:</td>
                    <td><input type="text" name="panjang"></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" name="hitung" value="hitung"></td>
                </tr>
            </table>
        </form>
    </p>

    <?php 
        if (isset($_GET['hitung'])) {
            $tinggi = $_GET['tinggi'];
            $panjang = $_GET['panjang'];

            if ($tinggi == "" or $panjang == "") {
                echo "<font color='blue'>Anda belum memasukkan nilai tinggi dan panjang";
            } else {
                $luas = $tinggi * $panjang;
                echo "Nilai Tinggi = ".$tinggi."<br>";
                echo "Nilai Panjang = ".$panjang."<br>";
                echo "Luas Persegi Panjang = ".$luas."<br>";
            }
        } else {
            echo "<font color='red'>Masukkan nilai tinggi & panjang !";
        }
    ?>
</body>
</html>