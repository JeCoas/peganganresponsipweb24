<?php
$nama = $_POST['nama'];
$email = $_POST['email'];
$pesan = $_POST['pesan'];
echo "Nama  : <b>$nama</b> <br>";
echo "Email : <b>$email</b> <br>";
echo "Pesan : <b>$pesan</b> <br>";
?>