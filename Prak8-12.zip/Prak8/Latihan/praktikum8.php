<!-- Praktikum 9.1 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktikum 8</title>
</head>
<body>
    <?php
    $txt = "Hello World";
    $x = 5;
    $y = 10.5;
    $Prodi = "Informatika";

    echo "Tampilkan variabel txt: $txt";
    echo "<br>";
    echo "$x <br>";
    echo "$y <br>";
    echo "Prodi di Fakultas Ilmu Komputer: $Prodi";
    ?>
</body>
</html>


<!-- Praktikum 9.2 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktikum 8</title>
</head>
<body>
    <?php
    // Mendefinisikan nilai konstanta
    define("nilaimax", "100");
    define("pi", "3.14");

    // Mencetak nilai konstanta
    print("Nilai maksimal : ".nilaimax);

    // Menggunakan konstanta dalam perhitungan
    $jarijari = 5;
    $luaslingkaran = pi * $jarijari * $jarijari;
    echo "<br> Luas lingkaran = ".$luaslingkaran;
    ?>
</body>
</html>


<!-- Praktikum 9.3 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktikum 8</title>
</head>
<body>
    <?php
    // Mendefinisikan variabel dengan berbagai macam tipe data
    $nim = "22.11.4813";
    $nama = "Nizar Mohammad Bintang Tri Pratama";
    $umur = 20;
    $nilai = 92.2;
    $status = TRUE;

    // Menampilkan data
    echo "NIM : ".$nim."<br>";
    echo "Nama : $nama <br>";
    print "Umur : ".$umur."<br>";
    printf("Nilai : %.3f <br>", $nilai);

    if ($status)
        echo "Status : Aktif";
    else
    echo "Status : Tidak Aktif";
    ?>
</body>
</html>


<!-- Praktikum 9.4 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktikum 8</title>
</head>
<body>
    <?php
    $angka1 = 15;
    $angka2 = 3;

    $penambahan = $angka1 + $angka2;
    $pengurangan = $angka1 - $angka2;
    $perkalian = $angka1 * $angka2;
    $pembagian = $angka1 / $angka2;
    $modulus = $angka1 % $angka2;

    echo "<h2> Perhitungan Aritmatika </h2>";
    echo "$angka1 + $angka2 = $penambahan";
    echo "<br>$angka1 - $angka2 = $pengurangan";
    echo "<br>$angka1 * $angka2 = $perkalian";
    echo "<br>$angka1 / $angka2 = $pembagian";
    echo "<br>$angka1 % $angka2 = $modulus";
    ?>
</body>
</html>


<!-- Praktikum 9.5 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktikum 8</title>
</head>
<body>
    <?php
    $string1 = "Pemrograman";
    $string2 = "Web Lanjut";
    $string3 = "Semester Ganjil";

    echo $string1." ".$string2." ".$string3;
    ?>
</body>
</html>


<!-- Praktikum 9.6 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktikum 8</title>
</head>
<body>
    <form action="action.php" method="GET">
        User : <input type="text" name="user" id=""><br>
        Password : <input type="password" name="pass" id=""><br>
        <input type="submit" value="PROSES">
    </form>
</body>
</html>


<!-- Praktikum 9.7 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktikum 8</title>
</head>
<body>
    <form action="action.php" method="POST">
        Nama : <input type="text" name="user" id=""><br>
        Email : <input type="text" name="email" id=""><br>
        Pesan : <textarea name="pesan"></textarea> <br>
        <input type="submit" value="Submit">
    </form>
</body>
</html>


<!-- Praktikum 9.8 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktikum 8</title>
</head>
<body>
    <form action="action.php" method="POST">
        Nama Anda = <input type="text" name="namaku"><br>
        Email Anda = <input type="email" name="emailku"><br>
        Alamat Anda <textarea name="alamatku"></textarea><br>
        <input type="submit" name="kirim" value="sent">
    </form>
    <?php
    if (isset($_POST['kirim'])) {
        echo "Nama Anda   : $_POST[namaku] <br>";
        echo "Email Anda  : $_POST[emailu] <br>";
        echo "Alamat Anda : $_POST[alamatku] <br>";
    }
    ?>
</body>
</html>


<!-- Challenge Pertemuan 8 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktikum 8</title>
</head>
<body>
    <form action="action.php" method="POST">
        Masukkan nama anda : <input type="text" name="nama"><br>
        Masukkan angka pertama (1-10) : <input type="number" name="angka1"><br>
        Masukkan angka kedua (1-10) : <input type="number" name="angka2"><br>
        <input type="submit" name="hitung" value="hitung">
    </form>
    <?php\
    $penjumlahan = $_POST[angka1] + $_POST[angka2];
    $pengurangan = $_POST[angka1] - $_POST[angka2];
    $perkalian = $_POST[angka1] * $_POST[angka2];
    $pembagian = $_POST[angka1] / $_POST[angka2];
    $modulus = $_POST[angka1] % $_POST[angka2];
    
    if (isset($_POST['hitung'])) {
        echo "<h2>Perhitungan Aritmatika</h2>";
        echo "Nama : $_POST[nama] <br>";
        echo "$_POST[angka1] + $_POST[angka2] = $penjumlahan <br>";
        echo "$_POST[angka1] - $_POST[angka2] = $pengurangan <br>";
        echo "$_POST[angka1] * $_POST[angka2] = $perkalian <br>";
        echo "$_POST[angka1] / $_POST[angka2] = $pembagian <br>";
        echo "$_POST[angka1] % $_POST[angka2] = $modulus";
    }
    ?>
</body>
</html>