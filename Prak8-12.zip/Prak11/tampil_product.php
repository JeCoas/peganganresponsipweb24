<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Product</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="mt-4 mb-4">CRUD Product</h1>
        <?php include 'koneksi.php';
        $sql = "SELECT * FROM product";
        $result = mysqli_query($link, $sql);
        ?>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Jenis</th>
                    <th>Jumlah</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['id_product']; ?></td>
                        <td><?php echo $row['nama_product']; ?></td>
                        <td><?php echo $row['jenis_product']; ?></td>
                        <td><?php echo $row['jumlah_product']; ?></td>
                        <td><?php echo $row['keterangan_product']; ?></td>
                        <td>
                            <a href="form_edit_product.php?id_product=<?php echo $row['id_product']; ?>" class="btn btn-primary">Edit</a>
                            <a href="delete_product.php?id_product=<?php echo $row['id_product']; ?>" class="btn btn-danger">Hapus</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <a href="form_tambah_product.php" class="btn btn-success">Tambah Product</a>
    </div>
</body>
</html>