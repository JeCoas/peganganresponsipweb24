<?php 
    include "koneksi.php";

    // Mendapatkan data dari form
    $id_product = $_POST['id_product'];
    $nama_product = $_POST['nama_product'];
    $jenis_product = $_POST['jenis_product'];
    $jumlah_product = $_POST['jumlah_product'];
    $keterangan_product = $_POST['keterangan_product'];

    // Query tambah data product
    $sql = "INSERT INTO product (id_product, nama_product, jenis_product, jumlah_product, keterangan_product) VALUES ('$id_product', '$nama_product', '$jenis_product', '$jumlah_product', '$keterangan_product')";
    if (mysqli_query($link, $sql)) {
        header("location:tampil_product.php");
    } else {
        header("location:form_tambah_product.php");
    }
?>