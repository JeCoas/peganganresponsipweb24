<?php
    // Koneksi ke database
    include "koneksi.php";

    // Mendapatkan ID product yang akan dihapus
    $id_product = $_GET['id'];

    // Query hapus data product
    $sql = "DELETE FROM product WHERE id_product=$id_product";
    if (mysqli_query($link, $sql)) {
        header("location:tampil_product.php");
    }
?>