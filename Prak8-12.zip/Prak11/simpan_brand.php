<?php
    include "koneksi.php";

    $sql = "INSERT INTO brand VALUES (2, 'Apple')";
    mysqli_query($link, $sql);
?>