<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="mt-4 mb-4">Edit Product</h1>
        <?php 
        // Koneksi ke database
        include "koneksi.php";
        
        // Mendapatkan data product berdasarkan ID
        $id_product = $_GET['id_product'];
        $sql = "SELECT * FROM product WHERE id_product='$id_product'";
        $result = mysqli_query($link, $sql);
        $data = mysqli_fetch_assoc($result);
        ?>
        <form method="POST" action="aksi_edit_product.php">
            <input type="hidden" name="id_product" value="<?php echo $data['id_product']; ?>">
            <div class="mb-3">
                <label for="id" class="form-label">ID</label>
                <input type="text" class="form-control" id="id_product" name="id_product" value="<?php echo $data['id_product']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" class="form-control" id="nama_product" name="nama_product" value="<?php echo $data['nama_product']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="jenis" class="form-label">Jenis</label>
                <input type="text" class="form-control" id="jenis_product" name="jenis_product" value="<?php echo $data['jenis_product']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="jumlah" class="form-label">Jumlah</label>
                <input type="number" class="form-control" id="jumlah_product" name="jumlah_product" value="<?php echo $data['jumlah_product']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="keterangan" class="form-label">Keterangan</label>
                <textarea class="form-control" name="keterangan_product" id="keterangan_product" rows="3" required><?php echo $data['keterangan_product']; ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="tampil_product.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>
</html>