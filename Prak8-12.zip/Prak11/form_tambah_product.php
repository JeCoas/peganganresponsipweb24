<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Product</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="mt-4 mb-4">Tambah Product</h1>
        <form method="POST" action="aksi_simpan_product.php">
            <div class="mb-3">
                <label for="nim" class="form-label">ID</label>
                <input type="text" class="form-control" id="id_product" name="id_product" required>
            </div>
            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" class="form-control" id="nama_product" name="nama_product" required>
            </div>
            <div class="mb-3">
                <label for="no_hp" class="form-label">Jenis</label>
                <input type="text" class="form-control" id="jenis_product" name="jenis_product" required>
            </div>
            <div class="mb-3">
                <label for="no_hp" class="form-label">Jumlah</label>
                <input type="number" class="form-control" id="jumlah_product" name="jumlah_product" required>
            </div>
            <div class="mb-3">
                <label for="alamat" class="form-label">Keterangan</label>
                <textarea class="form-control" name="keterangan_product" id="keterangan_product" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="tampil_product.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>
</html>